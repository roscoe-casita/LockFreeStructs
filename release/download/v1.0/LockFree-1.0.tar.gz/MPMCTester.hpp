


/*
 * MPMCTester.hpp
 *
 *  Created on: Jan 1, 2019
 *      Author: rcasita
 */

#ifndef MPMCTESTER_HPP_
#define MPMCTESTER_HPP_
#include <string>

void RunTests(std::string queue_name,int writers, int readers, int messages);



#endif /* MPMCTESTER_HPP_ */
